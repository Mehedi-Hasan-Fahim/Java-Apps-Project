create database expense_tracker_db;
use expense_tracker_db;

create table user_details(
id int not null Primary Key AUTO_INCREMENT,
name_ varchar(30) not null,
DOB DATE not null ,
email varchar(30) not null,
password_ varchar(20) not null
);


select* from user_details;
truncate table user_details;
drop table user_details;

CREATE TABLE expenses (
    ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(30) NOT NULL,
    password_ VARCHAR(20) NOT NULL,
    Date_Issue DATE NOT NULL,
    Category VARCHAR(20) NOT NULL,
    Remarks VARCHAR(30) NOT NULL,
    Amount INT NOT NULL
);

select* from expenses;
drop table expenses;
truncate table expenses;

create table category(
category_list varchar(20) not null,
email varchar(30) not null,
password_ varchar(20) not null,
CONSTRAINT unique_category_per_user PRIMARY KEY (category_list,email)
);
/*ALTER TABLE category ADD CONSTRAINT unique_category_per_user UNIQUE (category_list, email);*/

select* from category;
drop table category;
truncate table category;




